export class Userlogin {
    public email : string;
    public name : string;
    public _id : string;


constructor(p_email:string,p_id:string,p_name:string)
    {

        this.email = p_email;
        this.name = p_name;
        this._id = p_id;

    }


  
  
  
  }