// import { ProductModel } from '../models/product.model';
// import { Component, EventEmitter} from '@angular/core';

// export class ProductServices
// {

//     // ingridentsChanged = new EventEmitter<Ingredients[]>();
//     private products : ProductModel[] =
//     [
//         new ProductModel('anuj','this is testing','imag1.jpg',200),

//         new ProductModel('anuj','this is testing','imag1.jpg',200)
//     ];

//     getIngredients()
//     {
//         return this.products.slice();
//     }

//     // addIngredients(ingredients:Ingredients)
//     // {
//     //     this.ingredients.push(ingredients);
//     //     this.ingridentsChanged.emit(this.ingredients.slice());
//     // }

//     // OnAddNewIngredients(ingredients:Ingredients[])
//     // {
//     //     this.ingredients.push(...ingredients);
//     //     this.ingridentsChanged.emit(this.ingredients.slice());
//     // }

// }