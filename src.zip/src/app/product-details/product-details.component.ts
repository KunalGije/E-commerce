import { Component, OnInit, ViewChild, ElementRef,EventEmitter, Output } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { Product } from '../product.model';
import { CartServices } from '../cart.service';
import { Cart } from '../cart.model';
import { ProductNew } from '../productNew.model';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  id: number;

  kunal : any;
  
  @ViewChild('ingre_qty') ingre_qty : ElementRef;

  constructor( private route: ActivatedRoute,
    private  router: Router,private http:HttpClient,private cartServi:CartServices) { }

    ngOnInit() {

      let id2 = this.route.snapshot.paramMap.get('id'); 

      

      this.http.get("http://localhost:3006/api/product/"+id2).subscribe(posts =>{
        console.log("array"+posts);
  
       this.kunal =  posts;

       
       
      


     })
   
    ;
     
    }
    addTocart()
    {
      console.log(this.kunal._id);
      cart :Cart;
      const qty = this.ingre_qty.nativeElement.value; 

      
      let product_name = this.kunal.name; 
      let product_count = qty;  
      let product_image = this.kunal.productImagePath;  
      let product_price = this.kunal.price; 
      let product_total = qty * product_price;  

      console.log(this.kunal.name);
      console.log(qty);
     
      const cartItems = new Cart(this.kunal._id,product_name,product_count,product_image,product_price,product_total);

      console.log(cartItems);
      
      this.cartServi.addCart(cartItems);
      this.router.navigateByUrl('/mycart');
    }

}
